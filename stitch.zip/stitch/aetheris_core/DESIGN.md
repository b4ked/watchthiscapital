# Design System Specification

## 1. Overview & Creative North Star: "The Digital Curator"
This design system is built to position a technology holding company not just as a financial entity, but as an architectural force in innovation. The Creative North Star is **"The Digital Curator."** 

To move beyond the "template" look of modern SaaS, we employ an editorial approach. This means moving away from rigid, boxed-in grids and toward a layout defined by **intentional asymmetry, high-contrast typography scales, and tonal depth.** We treat the screen as a gallery space: large headlines command authority, while sophisticated layering creates a sense of physical permanence in a digital medium. Innovation is signaled through light (gradients and glassmorphism) rather than clutter.

---

## 2. Colors & Surface Philosophy
The palette is rooted in a "Deep Space" aesthetic—utilizing a dark charcoal foundation with high-energy electric blue accents to signify intelligence and kinetic energy.

### The "No-Line" Rule
**Explicit Instruction:** Designers are prohibited from using 1px solid borders for sectioning or containment. Boundaries must be defined solely through background color shifts. For example, a `surface_container_low` section should sit against a `surface` background to create a "zone" without a hard line.

### Surface Hierarchy & Nesting
Treat the UI as a series of physical layers. We use the Material surface tiers to define importance and "lift":
- **Base Layer:** `surface` (#131313) for the primary canvas.
- **Structural Zones:** `surface_container_low` (#1c1b1b) or `surface_container` (#201f1f) for distinct content blocks.
- **Interactive Elements:** `surface_container_high` (#2a2a2a) or `highest` (#353534) for floating cards or interactive modals.

### The "Glass & Gradient" Rule
To inject "soul" into the high-tech aesthetic:
- **Glassmorphism:** Use for floating navigation bars or overlays. Utilize `surface_variant` at 60% opacity with a `20px` backdrop-blur.
- **Signature Textures:** Main CTAs and Hero accents should utilize a subtle linear gradient (135°) from `primary` (#adc6ff) to `primary_container` (#006de6). This provides a sense of metallic sheen and premium finish.

---

## 3. Typography
We utilize a high-contrast pairing to balance technical precision with human-centric clarity.

*   **Display & Headlines (Space Grotesk):** This is our "Technical Signature." Its geometric, slightly industrial apertures feel innovative and authoritative. Use `display-lg` for hero statements to create an unmistakable editorial impact.
*   **Body & Labels (Inter):** Our "Functional Core." Inter provides maximum legibility for complex data and portfolio descriptions. 

**Typographic Editorializing:** 
- Use `label-md` in all-caps with 0.05em letter-spacing for category tags to mimic high-end print magazines.
- Maintain wide line-heights (1.5x - 1.6x) for `body-lg` to ensure the "Minimalist" promise is met through breathing room.

---

## 4. Elevation & Depth
In this system, depth is a product of light and layering, not structural scaffolding.

### The Layering Principle
Hierarchy is achieved by stacking surface tokens. A portfolio card (`surface_container_lowest`) placed inside a larger content section (`surface_container_low`) creates a soft, "recessed" look that feels integrated and high-end.

### Ambient Shadows
Shadows must never be black or high-contrast. 
- **Specification:** Use a blur radius of 30px–60px with an opacity of 4%–8%. 
- **Shadow Tint:** The shadow color should be a dark blue-tinted version of the background (derived from `on_secondary_fixed_variant`) to mimic how light behaves in a physical space.

### The "Ghost Border" Fallback
If a border is required for accessibility (e.g., input fields), use a **Ghost Border**: the `outline_variant` token at 15% opacity. Never use 100% opaque lines.

---

## 5. Components

### Bold Hero Sections
Heros should prioritize "The Big Idea." Use `display-lg` typography with a `primary` color gradient span. Layouts should be asymmetrical—text aligned to the left-third, with a "floating" glassmorphic element or high-quality 3D render on the right.

### Portfolio Cards
- **Structure:** No borders. Use `surface_container_low` as the card base. 
- **Interaction:** On hover, transition the background to `surface_container_high` and apply a subtle `primary` outer glow (8px blur, 10% opacity).
- **Content:** Forbid divider lines. Use 24px–32px of vertical padding to separate the header from the body text.

### Buttons
- **Primary:** Gradient fill (`primary` to `primary_container`), `on_primary` text, `md` (0.375rem) corner radius.
- **Secondary:** Transparent background with a "Ghost Border" and `primary` text.
- **States:** On hover, the primary button should "glow"—increasing the shadow spread, not changing the color brightness.

### Navigation
Floating top-bar using Glassmorphism. Use `surface_container_lowest` at 70% opacity with `backdrop-blur: 12px`. Link items should use `label-md` with an animated `primary` underline that grows from the center on hover.

### Input Fields
Minimalist "Underline-only" or "Ghost Box" style. Use `surface_container_highest` for the field background with a `sm` (0.125rem) corner radius. The error state uses `error` (#ffb4ab) for text and a 1px `error_container` ghost border.

---

## 6. Do's and Don'ts

### Do
*   **Do** use extreme whitespace. If a section feels "full," increase the padding by 20%.
*   **Do** use `tertiary` (#ffb59d) sparingly as a "warmth" highlight for specific call-outs or status indicators to offset the cool blue tones.
*   **Do** use `display-sm` for sub-headers to maintain the high-contrast editorial look.

### Don't
*   **Don't** use pure black (#000000). Use `surface_container_lowest` (#0e0e0e) to maintain tonal depth.
*   **Don't** use standard "drop shadows" on cards. Stick to tonal layering and ambient, low-opacity glows.
*   **Don't** use 1px dividers between list items. Use 16px of vertical space or a subtle shift to `surface_container_low`.
*   **Don't** crowd the logo. The holding company's mark needs a "halo" of empty space to signify prestige.

---

## 7. Accessibility
While the aesthetic is dark and sleek, contrast is non-negotiable. 
- All `on_surface` text must maintain a 4.5:1 ratio against `surface`.
- Interactive states (Focus) must be indicated by a `primary` outer glow (outline-offset: 2px) to ensure keyboard navigability without breaking the "No-Line" rule.